public class MyInt {
	private int val;
	public MyInt(int val) {
		this.val = val;
	}
	public void add() {
		val++;
	}
	public int getVal() {return val;}
}
