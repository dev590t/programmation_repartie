public interface Register<T> {
	public T read();
	public void write(T v);
}