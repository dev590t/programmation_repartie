public class SafeSMRSWBool implements Register<Boolean> {
	public Boolean read() { return true; }
	public void write(Boolean x) {}
}